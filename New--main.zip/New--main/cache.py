import hashlib
import re
import urllib.request
import json

def clean_hash(hash_str):
    return hash_str.strip().lower()

def check_online_api(hash_str):
    """Проверяет хеш по бесплатной онлайн-базе через API (например, MD5Online/Decrypter)"""
    print("[*] Ищу в онлайн-базах данных...")
    # Используем публичный сервис для дехеширования md5/sha1
    url = f"https://hashify.net{hash_str}"
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=5) as response:
            data = json.loads(response.read().decode())
            if data.get("success") and data.get("plaintext"):
                return data["plaintext"]
    except Exception:
        pass
    return None

def local_brute(hash_str, wordlist_path="passwords.txt"):
    """Ищет хеш по локальному текстовому словарю паролей"""
    print(f"[*] Проверяю по локальному словарю: {wordlist_path}...")
    
    hash_len = len(hash_str)
    algo = None
    if hash_len == 32: algo = 'md5'
    elif hash_len == 40: algo = 'sha1'
    
    if not algo:
        print("[-] Неизвестный формат хеша.")
        return None

    try:
        with open(wordlist_path, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                word = line.strip()
                # Хешируем слово из словаря для сравнения
                if algo == 'md5':
                    current_hash = hashlib.md5(word.encode()).hexdigest()
                else:
                    current_hash = hashlib.sha1(word.encode()).hexdigest()
                
                if current_hash == hash_str:
                    return word
    except FileNotFoundError:
        print(f"[-] Файл словаря '{wordlist_path}' не найден. Создайте его рядом со скриптом.")
    return None

def main():
    print("=== РАСХЕШИВАТОР ДЛЯ bWAPP ===")
    user_input = input("Введите хеш (MD5 или SHA-1): ")
    target_hash = clean_hash(user_input)

    if not re.match(r"^[a-f0-9]{32}$|^[a-f0-9]{40}$", target_hash):
        print("[-] Ошибка: введён некорректный хеш (должно быть 32 или 40 символов A-F, 0-9).")
        return

    # Шаг 1: Быстрый поиск в сети
    result = check_online_api(target_hash)
    
    # Шаг 2: Если в сети нет, ищем по словарю (например, rockyou.txt)
    if not result:
        result = local_brute(target_hash)

    if result:
        print(f"\n[+] УСПЕХ! Пароль найден: {result}")
    else:
        print("\n[-] Пароль не найден ни в сети, ни в словаре. Попробуйте увеличить словарь (например, скачать rockyou.txt).")

if __name__ == "__main__":
    main()